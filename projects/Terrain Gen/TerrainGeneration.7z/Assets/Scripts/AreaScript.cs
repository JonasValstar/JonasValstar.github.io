using UnityEngine;

public class AreaScript : MonoBehaviour
{
    /*
    // variables
    Transform player;
    public TerrainScript terrainScript;
    float maxDist = 25;

    void Start()
    {
        player = GameObject.Find("Player").GetComponent<Transform>();
        terrainScript = Camera.main.GetComponent<TerrainScript>();
    }

    void Update()
    {
        // checking the distance from player
        float dist = Mathf.Sqrt(Mathf.Pow(transform.position.x - player.position.x, 2) + Mathf.Pow(transform.position.z - player.position.z, 2));
        if (dist > maxDist) {
            terrainScript.RecalculateStructure(transform);
        }
    }
    */
}
